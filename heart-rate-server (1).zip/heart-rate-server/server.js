// ================================================================
// HEART RATE REALTIME SERVER
// Express (HTTP API for ESP32) + WebSocket (push to browser)
// ================================================================

const express = require('express');
const http = require('http');
const path = require('path');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = 3000;

// ----------------------------------------------------------------
// Middleware
// ----------------------------------------------------------------
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ----------------------------------------------------------------
// Keep the last known reading so a browser that connects late
// still sees something immediately instead of a blank screen.
// ----------------------------------------------------------------
let lastReading = {
  bpm: 0,
  avg10: 0,
  spo2: 0,
  finger: false,
  ts: Date.now()
};

// ----------------------------------------------------------------
// Broadcast a JSON payload to every connected browser
// ----------------------------------------------------------------
function broadcast(payload) {
  const msg = JSON.stringify(payload);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(msg);
    }
  });
}

// ----------------------------------------------------------------
// ESP32 posts here: { "bpm": 72, "avg10": 71.4, "spo2": 98, "finger": true }
// ----------------------------------------------------------------
app.post('/api/heart', (req, res) => {
  const { bpm, avg10, spo2, finger } = req.body || {};

  lastReading = {
    bpm: Number(bpm) || 0,
    avg10: Number(avg10) || 0,
    spo2: Number(spo2) || 0,
    finger: Boolean(finger),
    ts: Date.now()
  };

  console.log(
    `[${new Date().toLocaleTimeString()}] BPM=${lastReading.bpm} ` +
    `AVG10=${lastReading.avg10} SPO2=${lastReading.spo2} FINGER=${lastReading.finger}`
  );

  broadcast({ type: 'reading', data: lastReading });

  res.json({ status: 'ok' });
});

// Handy for debugging from a browser/Postman
app.get('/api/heart', (req, res) => {
  res.json(lastReading);
});

// ----------------------------------------------------------------
// WebSocket: send the last reading as soon as a client connects
// ----------------------------------------------------------------
wss.on('connection', (ws) => {
  console.log('Browser connected via WebSocket');

  ws.send(JSON.stringify({ type: 'reading', data: lastReading }));

  ws.on('close', () => {
    console.log('Browser disconnected');
  });
});

// ----------------------------------------------------------------
// Start
// ----------------------------------------------------------------
server.listen(PORT, '0.0.0.0', () => {
  console.log('================================================');
  console.log(' HEART RATE SERVER RUNNING');
  console.log(` HTTP + WS  : http://<this-machine-ip>:${PORT}`);
  console.log(` ESP32 POST : http://<this-machine-ip>:${PORT}/api/heart`);
  console.log('================================================');
});
